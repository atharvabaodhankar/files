#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void main(){
    int gd = DETECT, gm = 0;
    initgraph(&gd, &gm, "C:\\TC\\BGI");
    rectangle(200, 200, 300, 300);
    line(200, 200, 250, 125);
    line(250, 125, 300, 200);
    circle(250, 170, 10);
    rectangle(230, 250, 260, 300);
    getch();
    closegraph();
}