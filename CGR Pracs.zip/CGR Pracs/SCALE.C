#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<graphics.h>
void main()
{
int x1,y1,x2,y2,xt1,xt2,yt1,yt2;
float sx,sy;
int gd=DETECT,gm=0;
detectgraph(&gd,&gm);
initgraph(&gd,&gm,"c:\\turboc3\\bgi");
printf("Enter line end point(x1,y1) and (x2,y2)");
scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
printf("Enter scaling vector(sx,sy) ");
scanf("%f %f",&sx,&sy);
printf("\noriginal line");
line(x1,y1,x2,y2);
setcolor(YELLOW);
xt1=x1*sx;
xt2=x2*sx;
yt1=y1*sy;
yt2=y2*sy;
printf("\nScaled linein yellow color");
line(xt1,yt1,xt2,yt2);
printf("\nEnter any key");
getch();
cleardevice();
printf("\nScaled polygon RED color");
rectangle(x1,y1,x2,y2);
setcolor(RED);
rectangle(xt1,yt1,xt2,yt2);
getch();
closegraph();
}