#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<dos.h>
#include<stdlib.h>

void main()
{
	int gd = DETECT , gm = 0;
	int x ,y , dx , dy , tdx , tdy , tdxy , k , p , x1 , y1  , x2 , y2;
	detectgraph(&gd , &gm);
	initgraph(&gd , &gm , "C:\\TURBOC3\\BGI");

	printf("Enter the x1 y1 and x2 y2 : " );
	scanf("%d%d%d%d" , &x1, &y1 , &x2 , &y2);

	dx = x2 - x1;
	dy = y2 - y1;

	tdx = 2 * dx;
	tdy = 2 * dy;
	tdxy = tdy - tdx;
	p = tdy - dx;
	x = x1;
	y = y1;


	putpixel(x,y,15);

	for(k = 1 ; k<=dx;k++)
	{
		if(p < 0)
		{
			x++;
			p = p + tdy;
			putpixel(x,y,15);
		}else{
			x++;
			y++;
			p = p + tdxy;
			putpixel(x,y,4);
		}
	}





	getch();
	closegraph();
}
