#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>

    void    bfill(int x,int y,int fc,int bc)
     {
     int current;
     current=getpixel(x,y);
     if((current!=bc)&&(current!=fc))
     {
	//setcolor(fc);
	putpixel(x,y,fc);
	delay(5);
	bfill(x+1,y,fc,bc);
	bfill(x-1,y,fc,bc);
	bfill(x,y+1,fc,bc);
	bfill(x,y-1,fc,bc);

      }
    }
    void  main(void)
   {
    int xc,yc,r,gd = DETECT, gm=0;

     initgraph(&gd,&gm, "C:\\Tc\\BGI");
      rectangle(100,100,150,150);
      bfill(110,110,4,15);
       getch();
     closegraph();
     getch();
    }