#include<conio.h>
#include<stdio.h>
#include<graphics.h>
#include<stdlib.h>
#include<math.h>
#include<dos.h>

void main()
{
int gd = DETECT , gm = 0;
float x , y , x1 ,y1 ,x2 ,y2 , dx ,dy , tdx, tdy , tdxy , steps , k , xinc , yinc;
detectgraph( &gd , &gm);
initgraph( &gd , &gm , "C:\\TURBOC3\\BGI");

printf("Enter the x1 y1 & x2 y2 : ");
scanf("%f%f%f%f" , &x1 , &y1 , &x2 , &y2);

dx = x2 - x1;
dy = y2 - y1;

tdx = 2 * dx;
tdy = 2 * dy;
tdxy = tdy - dx;

if(fabs(dx) > fabs(dy))
{
	steps = fabs(dx);
}else
{
	steps = fabs(dy);
}
xinc = dx / steps;
yinc = dy / steps;

x = x1;
y = y1;


putpixel(x+0.5,y+0.5,15);


for(k = 1 ; k<=steps ; k++)
{
	x += xinc;
	y += yinc;
	putpixel(x+0.5 , y+0.5 , 15);
	delay(5);
}




getch();
closegraph();
}